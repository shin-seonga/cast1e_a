// app.js

const express = require('express');
const mysql = require('mysql');
const ejs = require('ejs');
const bodyParser = require('body-parser');

const app = express();
const port = 80;

// MySQL 연결 설정
const connection = mysql.createConnection({
  host: 'reservation.c7mwaou2semb.ap-northeast-2.rds.amazonaws.com',
  user: 'admin',
  password: 'pxVq_esNuTrQ?2T.COqf7*6wCAsF',
  port:3306,
  database: 'reservation',
});

// MySQL 연결
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL');
  }
});

// 데이터베이스 연결 에러 이벤트 처리
connection.on('error', (err) => {
  console.error('Database connection error:', err);
});

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.urlencoded({ extended: false }));

// 정적 파일 서빙 (이미지를 서빙하기 위해 teams 폴더를 사용)
app.use('/teams', express.static('views/teams'));

// 라우팅 //
app.get('/', (req, res) => {
  res.render('index');
});

app.get('/reservation', (req, res) => {
  res.render('reservation');
});

app.get('/team', (req, res) => {
  res.render('team', {
    teamMembers: [
      { name: '강태완', image: '1.png', description: '강태완 소개 내용...' },
      { name: '김수영', image: '2.png', description: '김수영 소개 내용...' },
      { name: '신성아', image: '3.png', description: '신성아 소개 내용...' },
      { name: '최승범', image: '4.png', description: '최승범 소개 내용...' },
      { name: '최진영', image: '5.png', description: '최진영 소개 내용...' },
    ],
  });
});

app.post('/search', (req, res) => {
  const name = req.body.PERSON ? `%${req.body.PERSON.toLowerCase()}%` : ''; // 검색어가 있는 경우, 소문자로 변환하여 일부 일치 검색을 위해 '%'로 감싸기
  const contact = req.body.CONTACT || '';
  const seat = req.body.SEAT || '';
  const others = req.body.OTHER || '';

  // MySQL 쿼리 작성 (일부 일치 및 대소문자 구분 없이 검색)
  const query = `SELECT * FROM entity_info WHERE 
    (LOWER(PERSON) LIKE '${name}' OR '${name}' = '') 
    AND (CONTACT = '${contact}' OR '${contact}' = '') 
    AND (SEAT = '${seat}' OR '${seat}' = '') 
    AND (OTHER = '${others}' OR '${others}' = '')`;

  console.log('Query:', query); // 실행되는 쿼리 콘솔에 출력

  // MySQL에서 검색 수행
  connection.query(query, (error, results, fields) => {
    if (error) {
      console.error('Error executing query:', error);
      return res.status(500).send('Internal Server Error');
    }

    // 검색 결과를 클라이언트에게 전송
    res.render('search_result', { results });
  });
});



app.listen(port, () => {
  // console.log(`Server is running at http://localhost:${port}`);
});